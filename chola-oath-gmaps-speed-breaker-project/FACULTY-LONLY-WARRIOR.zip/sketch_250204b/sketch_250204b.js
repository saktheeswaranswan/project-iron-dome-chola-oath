let video;
let missile;
let domeRadius = 300;
let missilePos = createVector(-500, 100, 100); // Starting position of the missile
let domeCenter;
let domeAngle = 0;

function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL); // Create 3D canvas
  video = createCapture(VIDEO); // Create video capture for live feed
  video.size(640, 480); // Adjust the video size
  video.hide(); // Hide the actual video element

  domeCenter = createVector(0, 0, 0); // Dome center in 3D space

  missile = new Missile();
}

function draw() {
  background(200);

  // Rotate the view to simulate VR-like movement
  rotateY(domeAngle);
  
  // Draw transparent dome
  push();
  noFill();
  stroke(200, 100, 100);
  strokeWeight(2);
  ellipse(0, 0, domeRadius * 2, domeRadius * 2);  // Dome edge
  sphere(domeRadius);  // Transparent dome effect
  pop();
  
  // Display video from webcam inside the dome
  if (video.loaded()) {
    push();
    translate(0, 0, -domeRadius + 20);  // Position in front of dome
    texture(video);  // Apply the webcam feed as a texture
    plane(domeRadius * 2, domeRadius * 2);  // Video texture on plane
    pop();
  } else {
    console.log("Video not loaded yet!");
  }
  
  // Animate and draw missile
  missile.update();
  missile.display();

  // Check if missile enters the dome
  if (missilePos.dist(domeCenter) < domeRadius) {
    missile.showInsideDome();
  }

  // Update camera angle for the VR effect
  domeAngle += 0.005;
}

// Missile object
class Missile {
  constructor() {
    this.velocity = createVector(3, 0, 0);  // Missile speed
  }

  update() {
    missilePos.add(this.velocity); // Move missile
  }

  display() {
    push();
    translate(missilePos.x, missilePos.y, missilePos.z); // Position the missile
    fill(255, 0, 0);
    cone(10, 50);  // Represent missile as a cone
    pop();
  }

  showInsideDome() {
    push();
    translate(missilePos.x, missilePos.y, missilePos.z); 
    fill(0, 255, 0);
    sphere(10); // Show missile as a green sphere when inside dome
    pop();
  }
}
