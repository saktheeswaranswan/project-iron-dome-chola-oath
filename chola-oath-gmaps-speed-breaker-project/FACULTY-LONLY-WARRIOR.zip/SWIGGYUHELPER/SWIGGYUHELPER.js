let coimbatoreNodes = [];
let maduraiNodes = [];
let chennaiNodes = [];
let salemNodes = [];
let nodeCount = 10000000000000000000000000; // Number of nodes to fetch per district

function setup() {
  createCanvas(800, 600);
  fetchDistrictNodes("Coimbatore");
  fetchDistrictNodes("Madurai");
  fetchDistrictNodes("Chennai");
  fetchDistrictNodes("Salem");
}

function fetchDistrictNodes(district) {
  let apiUrl = "https://overpass-api.de/api/interpreter";
  let query = `
  [out:json];
  area["name"="${district}"]->.searchArea;
  (
    node["highway"](area.searchArea);
    node["amenity"](area.searchArea);
    node["shop"](area.searchArea);
    node["school"](area.searchArea);
    node["hospital"](area.searchArea);
    node["park"](area.searchArea);
    node["fuel"](area.searchArea);
  );
  out body;
  >;
  out skel qt;
  `;
  
  let params = {
    method: 'POST',
    body: `data=${encodeURIComponent(query)}`
  };

  fetch(apiUrl, params)
    .then(response => response.json())
    .then(data => {
      let nodes = data.elements.slice(0, nodeCount);  // Limit to 1000 nodes
      switch(district) {
        case "Coimbatore":
          coimbatoreNodes = nodes;
          break;
        case "Madurai":
          maduraiNodes = nodes;
          break;
        case "Chennai":
          chennaiNodes = nodes;
          break;
        case "Salem":
          salemNodes = nodes;
          break;
      }
      saveCSV(district, nodes);
    })
    .catch(error => console.error('Error fetching data:', error));
}

// Function to calculate the distance between two points using the Haversine formula
function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth radius in km
  const φ1 = radians(lat1);
  const φ2 = radians(lat2);
  const Δφ = radians(lat2 - lat1);
  const Δλ = radians(lon2 - lon1);

  const a = sin(Δφ / 2) * sin(Δφ / 2) +
            cos(φ1) * cos(φ2) *
            sin(Δλ / 2) * sin(Δλ / 2);
  const c = 2 * atan2(sqrt(a), sqrt(1 - a));

  const distance = R * c;  // Distance in km
  return distance;
}

// Function to save the data as a CSV
function saveCSV(district, nodes) {
  let csv = "NodeID,Latitude,Longitude,GoogleMapsLink,ConnectingNodeID,DistanceKM,TravelTimeSeconds,TravelTimeMinutes\n";
  
  for (let i = 0; i < nodes.length; i++) {
    let node = nodes[i];
    let lat = node.lat;
    let lon = node.lon;
    let googleMapsLink = `https://www.google.com/maps?q=${lat},${lon}`;
    let connectingNodeID = (i === nodes.length - 1) ? nodes[0].id : nodes[i + 1].id;  // Close the graph
    
    // Calculate distance between nodes
    let nextNode = nodes[i + 1] || nodes[0];  // Connect last node to the first node
    let distance = haversine(lat, lon, nextNode.lat, nextNode.lon);  // Distance in km
    
    // Assuming average speed for car (40 km/h), convert to seconds and minutes
    let speed = 40; // Average speed of car in km/h
    let timeInSeconds = (distance / speed) * 3600;  // Convert hours to seconds
    let timeInMinutes = timeInSeconds / 60;  // Convert seconds to minutes
    
    // Append data to the CSV string
    csv += `${node.id},${lat},${lon},${googleMapsLink},${connectingNodeID},${distance.toFixed(2)},${timeInSeconds.toFixed(2)},${timeInMinutes.toFixed(2)}\n`;
  }
  
  // Create a Blob and trigger download
  let blob = new Blob([csv], { type: "text/csv" });
  let link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${district}_nodes_graph_with_distances_and_travel_time.csv`;
  link.click();
}

function draw() {
  background(255);
  // Optional: Visualize the nodes as points on canvas (for debugging)
  let allNodes = coimbatoreNodes.concat(maduraiNodes, chennaiNodes, salemNodes);
  for (let i = 0; i < allNodes.length; i++) {
    let x = map(allNodes[i].lon, 78.0, 79.0, 0, width);  // Map longitude to x-coordinate
    let y = map(allNodes[i].lat, 9.0, 11.0, height, 0); // Map latitude to y-coordinate
    ellipse(x, y, 5, 5); // Draw each node as a small circle
  }
}
