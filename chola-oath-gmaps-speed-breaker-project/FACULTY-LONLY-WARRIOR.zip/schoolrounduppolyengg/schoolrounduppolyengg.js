let schoolsData = [];
let collegesData = [];
let polytechnicsData = [];
let artsInstitutionsData = [];

function setup() {
  createCanvas(800, 600);
  background(255);

  // Define area for query (example: Madurai)
  let latMin = 9.9, latMax = 10.2;  // Latitude range
  let lonMin = 78.1, lonMax = 78.2; // Longitude range

  // Send Overpass queries for schools, colleges, polytechnics, arts institutions
  fetchData(latMin, latMax, lonMin, lonMax, 'school').then(data => {
    if (data) processNodes(data.elements, 'schools');
  });
  fetchData(latMin, latMax, lonMin, lonMax, 'college').then(data => {
    if (data) processNodes(data.elements, 'colleges');
  });
  fetchData(latMin, latMax, lonMin, lonMax, 'polytechnic').then(data => {
    if (data) processNodes(data.elements, 'polytechnics');
  });
  fetchData(latMin, latMax, lonMin, lonMax, 'arts_centre').then(data => {
    if (data) processNodes(data.elements, 'artsInstitutions');
  });

  // After gathering data, run shortest path calculations
  setTimeout(() => {
    calculateShortestPaths();
    exportCSV();
  }, 5000); // Adjust time as per expected delay in data fetching
}

async function fetchData(latMin, latMax, lonMin, lonMax, amenity) {
  const overpassUrl = 'https://overpass-api.de/api/interpreter';

  // Overpass query for different amenities (school, college, etc.)
  const query = `
  [out:json];
  node["amenity"="${amenity}"](${latMin},${lonMin},${latMax},${lonMax});
  out body;
  >;
  out skel qt;
  `;

  const response = await fetch(overpassUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'data=' + encodeURIComponent(query)
  });

  if (!response.ok) {
    console.error('Request failed with status:', response.status);
    return null;
  }

  const data = await response.json();
  return data;
}

function processNodes(elements, amenityCategory) {
  elements.forEach(element => {
    if (element.lat && element.lon) {
      let amenity = element.amenity || 'Unknown';
      let lat = element.lat;
      let lon = element.lon;
      let phone = element.phone || 'N/A';
      let email = element.email || 'N/A';
      let name = element.tags?.name || 'Unnamed';
      let locationLink = `https://www.google.com/maps?q=${lat},${lon}`;

      // For institutions, gather relevant details
      let hodPhone = element.tags?.["contact:phone"] || 'N/A';
      let hodEmail = element.tags?.["contact:email"] || 'N/A';
      let principalPhone = element.tags?.["contact:phone"] || 'N/A';
      let principalEmail = element.tags?.["contact:email"] || 'N/A';
      let department = element.tags?.["department"] || 'N/A';

      // Store the processed node into appropriate category
      let node = {
        name,
        amenity,
        lat,
        lon,
        phone,
        email,
        hodPhone,
        hodEmail,
        principalPhone,
        principalEmail,
        department,
        locationLink
      };

      // Store in the corresponding array based on category
      if (amenityCategory === 'schools') {
        schoolsData.push(node);
      } else if (amenityCategory === 'colleges') {
        collegesData.push(node);
      } else if (amenityCategory === 'polytechnics') {
        polytechnicsData.push(node);
      } else if (amenityCategory === 'artsInstitutions') {
        artsInstitutionsData.push(node);
      }
    }
  });
}

function calculateShortestPaths() {
  // Example: Apply a shortest path algorithm (e.g., Dijkstra) between all nodes
  console.log("Calculating shortest paths...");
  
  // For now, this is a placeholder. You would apply a shortest path algorithm here (e.g., Dijkstra or A*)
}

function exportCSV() {
  // Export each category as CSV
  exportCategoryToCSV(schoolsData, 'schools');
  exportCategoryToCSV(collegesData, 'colleges');
  exportCategoryToCSV(polytechnicsData, 'polytechnics');
  exportCategoryToCSV(artsInstitutionsData, 'artsInstitutions');
}

function exportCategoryToCSV(data, categoryName) {
  let csv = "Name,Amenity,Latitude,Longitude,Phone,Email,HOD Phone,HOD Email,Principal Phone,Principal Email,Department,Location Link\n";

  data.forEach(node => {
    csv += `${node.name},${node.amenity},${node.lat},${node.lon},${node.phone},${node.email},${node.hodPhone},${node.hodEmail},${node.principalPhone},${node.principalEmail},${node.department},${node.locationLink}\n`;
  });

  // Create CSV file for the category
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${categoryName}.csv`;
  link.click();
}

function draw() {
  fill(0);
  textSize(16);
  text("Fetching and processing data...", 20, height / 2);
}
